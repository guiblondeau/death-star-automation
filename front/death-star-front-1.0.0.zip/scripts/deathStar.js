var deathStarApp = angular.module('deathStar', []);
